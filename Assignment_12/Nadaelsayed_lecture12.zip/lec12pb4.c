#include <stdio.h>
#include <limits.h>
int getmin(int x[],int* m);
int main(){
int x[10],min=INT_MAX; // if user try to enter a big values

printf("Please enter an array of 10 elements to find its min. element: ");
for (int i=0; i<10; i++){
		scanf("%d", x+i);
}
min= getmin(x, &min);
printf("The min. element of this array is: %d",min);
return 0;
}
int getmin(int *x,int* m){//sending 2 arrays one of them for reverse value 
for (int i=0;i<10;i++){
		if(*(x+i) < *m)
		{
			*m=*(x+i);
		}
  }
return *m;
}