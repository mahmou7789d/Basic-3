#include <stdio.h>

int get_lenght(char *str, int n/*,int* count*/);
int main() {
    char str[50]; // Increased array size to accommodate null terminator
	int i,res;
	printf("Please enter the string as max. 50 character: ");
	scanf(" %[^\n]s", str); // to allow space at input string for one line //keep space at beginning to avoid stucking
	res= get_lenght(str,0);
	printf("The lenght of the string is: %d",res);
return 0;
}

int get_lenght(char* str, int n/*,int* count*/){// const char to avoid (least prevelage)
/*	int i;
	*count=0;
for (i=0; str[i] != '\0'; i++){
	(*count)++;//This format is necessary to correctly increment the value pointed to by count.
}*/
char *start=str; // if const char* str can apply this line
//(warning: initialization discards 'const' qualifier from pointer target type [-Wdiscarded-qualifiers])
while(*str != '\0') //anather solution with while loop
{
//(*count)++;
str++;	
}
return ((str-start)/sizeof(char));//calculate diferent in addreses divided by datatype to find lenght
//return *count;
}