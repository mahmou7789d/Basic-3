#include <stdio.h>
void copy(int x[],int xr[]);
int main(){
int x[10],y[10];

printf("Please enter 10 elements of the original array: ");
for (int i=0; i<10; i++){
	//to check input validation
		if(scanf("%d", x+i)!=1)//!=1 --> means input is anumerical value (character)
		{
			printf("Invalid input!");
			return 1;// if return 1 means that the program does not execute successfully and there is some error		
			}
}
copy(x, y);
printf("Elements of the new array are: ");
for (int i=0; i<10; i++){
	printf("%d ", *(y+i));
}
return 0; //return 0 means that the program executes successfully and exiting the program
}
void copy(int *x,int *y){
for (int i=0;i<10;i++){
		*(y+i)=*(x+i);
  }

}