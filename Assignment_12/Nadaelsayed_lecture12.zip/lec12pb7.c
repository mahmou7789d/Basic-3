#include <stdio.h>
int get_lenght(char a[]);
//void letters(char *str, int n,char* c,char* d);
void letters(char *str,int n, char* b);
int main() {
    char str[50],b[4],ch1,ch2; // Increased array size to accommodate null terminator
	int i, res;
	printf("Please enter the string as max. 50 character: ");
	scanf(" %[^\n]s", str); // to allow space at input string for one line //keep space at beginning to avoid stucking
	res=get_lenght(str);
	//letters(str,res,&ch1,&ch2);
	letters(str,res,b);
	i=0;
	while(b[i] != '\0')
	{
	printf("%c",b[i]);
	i++;	
	}
return 0;
}

int get_lenght(char *a){
	int j;
for (j=0; a[j] != '\0'; j++);
return j;
}
/*void letters(char *str, int n,char* c,char* d){
for (int i=0;i<n; i++)
{
	//getting last 2 characters
	*c = *(str+(n-1));
	*d = *(str+(n-2));
	
}
printf("%c %c",*c,*d);
return ;
}*/
void letters(char *str,int n, char *b)
{	for (int i=0;i<n; i++)
{	*(b+0) = *(str+(n-1));
	*(b+1) = ' ';
	*(b+2) = *(str+(n-2));
	*(b+3) = '\0';	
}
}