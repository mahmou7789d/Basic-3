#include <stdio.h>

long long sum(int* arr, int size, long long* add);

int main() {
    int arr[10]; long long res=0; int len=10;
	int* ptr=arr;
    printf("Please enter 10 array elements to compute the sum of the array elements\n");
    printf("Enter your array: ");
    for (int i = 0; i < len; i++) {
        scanf("%d", ptr+i);//ptr+i = &arr[i]
    }	
    res = sum(arr,len, &res);
    printf("The sum of array elements: %lld", res);//lld --> lon long specifier
    return 0;
}

long long sum(int* arr, int size, long long* add) {//passing result of sum using pointer
    *add = 0;  // Initialize add to 0
    for (int i = 0; i < size; i++) {
        *add += *(arr+i); //*(arr+i) = arr[i]
    }
    return *add;
}