#include <stdio.h>
void reverse(int* a,int* ar);
/*int main(){
int a[10],ar[10];

printf("Please enter an array of 10 elements to reverse it: ");
for (int i=0; i<10; i++){
		scanf("%d", a+i);
}
reverse(a, ar);
printf("The array after reversing it: ");
for (int i=0; i<10; i++){
	printf("%d ", *(ar+i));
}
return 0;
}
void reverse(int* a,int* ar){//sending 2 arrays one of them for reverse value 
for (int i=0,j=9;i<10;i++,j--){
		*(ar+j)=*(a+i);
	
  }

}*/
//******************************************************************************************
//another solution
int main(){
int a[10],len=10;

printf("Please enter an array of 10 elements to reverse it: ");
for (int i=0; i<10; i++){
		scanf("%d", a+i);
}
reverse(a, (a+len-1));
printf("The array after reversing it: ");
for (int i=0; i<10; i++){
	printf("%d ", *(a+i));
}
return 0;
}
void reverse(int* start,int* end){//sending 2 arrays one of them for reverse value 
while(start<end)
{
	int temp=*start;
	*start=*end;
	*end=temp;
start++;
end--;	
}}
//******************************************************************************************
//another solution (using recursion) 
/*
int main(){
int a[10],len=10;

printf("Please enter an array of 10 elements to reverse it: ");
for (int i=0; i<10; i++){
		scanf("%d", a+i);
}
reverse(a, (a+len-1));
printf("The array after reversing it: ");
for (int i=0; i<10; i++){
	printf("%d ", *(a+i));
}
return 0;
}
void reverse(int* start,int* end){//sending 2 arrays one of them for reverse value 
	if (start>=end){
		return 0;
	}
	int temp=*start;
	*start=*end;
	*end=temp;
return(reverse(start+1,end-1))
}
*/