#include <stdio.h>
void swap(int *x,int *y);
int main(){
int i,x[10],y[10];
printf("This program to swap 2 arrays of 10 elements\n");
printf("Please enter 1st array of 10 elements: ");
for (i=0; i<10; i++){
	if(scanf("%d", x+i)!=1)//!=1 --> means input is anumerical value (character)
	{
		printf("Invalid input!");
		return 1;// if return 1 means that the program does not execute successfully and there is some error		
		}
}
printf("Please enter 2nd array of 10 elements: ");
for (i=0; i<10; i++){
	if(scanf("%d", y+i)!=1)
	{
		printf("Invalid input!");
		return 1;
		}
}
swap(a, b);
printf("The 1st arrays after swapping: ");
for (i=0; i<10; i++){
	printf("%d ", *(x+i));
}
printf("\n");
printf("The 2nd arrays after swapping: ");
for (i=0; i<10; i++){
	printf("%d ", *(y+i));
}
return 0;
}
void swap(int *x,int *y){//sending 2 arrays one of them for reverse value 
int temp[10];
for (int i=0,j=0;i<10;i++,j++){
/*		temp[j]=x[i];
		x[i]=y[j];
		y[i]=temp[j];
*/
//****************************
//another solution for swapping
		*(x+i)=*(x+i) ^ *(y+i);
		*(y+i)=*(x+i) ^ *(y+i);
		*(x+i)=*(x+i) ^ *(y+i);
//****************************
//another solution for swapping
		*(x+i)=*(x+i) + *(y+i);
		*(y+i)=*(x+i) - *(y+i);
		*(x+i)=*(x+i) - *(y+i);
//****************************
//another solution for swapping
		*(x+i)=*(x+i) * *(y+i);
		*(y+i)=*(x+i) / *(y+i);
		*(x+i)=*(x+i) / *(y+i);
}
}